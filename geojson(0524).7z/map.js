function createMap(csvData){
    csvData.forEach(function(d){
        d.Percentage = d.Percentage.replace("%", "");
        d.Percentage = +d.Percentage;
    })
    //Width and height
    var w = 1000;
    var h = 620;

    //Define map projection
    var projection = d3.geoMercator()
                           .translate([0, 0])
                           .scale(1);

    //Define path generator
    var path = d3.geoPath()
                     .projection(projection);

    //Create SVG element
    var svg = d3.select("#map")
                .append("svg").attr("id", "mapsvg")
                .attr("width", w)
                .attr("height", h);

    //add tooltip
    var div = d3.select("body").append("div")
        .attr("class", "tooltip-donut")
        .style("opacity", 0);
    
    //Load in GeoJSON data
    d3.json("uganda_districts.json").then(function(json) {

        // Calculate bounding box transforms for entire collection
        var b = path.bounds( json ),
        s = .95 / Math.max((b[1][0] - b[0][0]) / w, (b[1][1] - b[0][1]) / h),
        t = [(w - s * (b[1][0] + b[0][0])) / 2, (h - s * (b[1][1] + b[0][1])) / 2];

        // Update the projection
        projection
        .scale(s)
        .translate(t);

       
        var CSelected = d3.select(".Cselection").node().value;
        let CfilterData = csvData.filter(function(d){ return d.Candidate==CSelected;})
        
        var uniqueParty = [...new Set(CfilterData.map(function(d) {
            return d.Party;
        }))];
        let colorValue = null;
        if(uniqueParty[0]=="FDC"){
            colorValue = "Blues";
        }
        else if(uniqueParty[0]=="Independent"){
            colorValue = "Greys";
        }
        else if(uniqueParty[0]=="NUP"){
            colorValue = "Reds";
        }
        else if(uniqueParty[0]=="DP"){
            colorValue = "Greens";
        }
        else if(uniqueParty[0]=="ANT"){
            colorValue = "Purples";
        }else{
            colorValue = "Oranges";
        }
        var color = d3.scaleSequential(d3["interpolate" + colorValue])
        let min = d3.min(CfilterData, function(d){ return +d.Percentage;})
        let max = d3.max(CfilterData, function(d){ return +d.Percentage;})
        color.domain([min, max]);
      
        //Bind data and create one path per GeoJSON feature
        var mapPath = svg.selectAll("path")
        .data(json.features)
        .enter()
        .append("path")
        .attr("d", path)
        .style("fill", function(d){
            let fcd = CfilterData.filter(function(cd){ return cd.District.toLowerCase()==d.properties.Dist_Name.toLowerCase();})
            if(fcd.length!=0){
                return color(+fcd[0].Percentage);
            }else{
                return "white";
            }            
        })
        .style("stroke-width", "1px")
        .style("stroke", "#000000")
        .on("mouseover", function(d) { //show tooltip on mouse hover
            let fcd = CfilterData.filter(function(cd){ return cd.District.toLowerCase()==d.properties.Dist_Name.toLowerCase();})
            div.transition()
            .duration(50)
            .style("opacity", 1);
            
            if(fcd.length!=0){
                div.html("District: "+fcd[0].District + "</br>" + "Candidate: "+ fcd[0].Candidate + "</br>" +"Party: "+ fcd[0].Party + "</br>" +"Voters: "+ fcd[0].Voters + "</br>" +"Percentage: "+ fcd[0].Percentage + "%" + "</br>"  )
                
                div.style("left", (d3.event.pageX ) + "px")
                .style("top", (d3.event.pageY- 28) + "px");
            }
        })
        .on("mouseout", function(d) {//hide tooltip on mouse hover
            div.transition()
             .duration(50)
             .style("opacity", 0);
        });
        d3.select("#dropDown").on("change", function(d){
            var CSelected = d3.select(".Cselection").node().value;
            CfilterData = csvData.filter(function(d){ return d.Candidate==CSelected;})
            
            uniqueParty = [...new Set(CfilterData.map(function(d) {
                return d.Party;
            }))];
            let colorValue = null;
            if(uniqueParty[0]=="FDC"){
                colorValue = "Blues";
            }
            else if(uniqueParty[0]=="Independent"){
                colorValue = "Greys";
            }
            else if(uniqueParty[0]=="NUP"){
                colorValue = "Reds";
            }
            else if(uniqueParty[0]=="DP"){
                colorValue = "Greens";
            }
            else if(uniqueParty[0]=="ANT"){
                colorValue = "Purples";
            }else{
                colorValue = "Oranges";
            }
            var color = d3.scaleSequential(d3["interpolate" + colorValue])
            let min = d3.min(CfilterData, function(d){ return +d.Percentage;})
            let max = d3.max(CfilterData, function(d){ return +d.Percentage;})
            
            color.domain([min, max]);
            mapPath.style("fill", function(d){
                let fcd = CfilterData.filter(function(cd){ return cd.District.toLowerCase()==d.properties.Dist_Name.toLowerCase();})
                if(fcd.length!=0){
                    return color(+fcd[0].Percentage);
                }else{
                    return "white";
                }    
            })
            
        })
        //mapPath.append("title").text(function(d){ return d.properties.Dist_Name;})

        // create a list of keys
        var keys = ["FDC", "Independent", "NUP", "DP", "ANT","NRM"]

        // Add one dot in the legend for each name.
        var size = 20
        svg.selectAll("mydots")
        .data(keys)
        .enter()
        .append("rect")
            .attr("x", 100)
            .attr("y", function(d,i){ return 100 + i*(size+5)}) // 100 is where the first dot appears. 25 is the distance between dots
            .attr("width", size)
            .attr("height", size)
            .style("fill", function(d){ 
                if(d=="FDC"){
                    return "#0e559d";
                }
                else if(d=="Independent"){
                    return "#898989";
                }
                else if(d=="NUP"){
                    return "#71020e";
                }
                else if(d=="DP"){
                    return "#097131";
                }
                else if(d=="ANT"){
                    return "#3f007d";
                }else{
                    return "Orange";
                }
            })

        // Add one dot in the legend for each name.
        svg.selectAll("mylabels")
        .data(keys)
        .enter()
        .append("text")
            .attr("x", 100 + size*1.2)
            .attr("y", function(d,i){ return 100 + i*(size+5) + (size/2)}) // 100 is where the first dot appears. 25 is the distance between dots
            .style("fill", function(d){ return color(d)})
            .text(function(d){ return d})
            .attr("text-anchor", "left")
            .style("alignment-baseline", "middle")

    });
}

d3.csv("ugelection.csv").then(function(csvData){

    var uniqueCandidate = [...new Set(csvData.map(function(d) {
        return d.Candidate;
    }))];
	
    //create dropdown lists
    var dropDown = d3.select("#dropDown")
      .append("select")
      .attr("class", "Cselection")
      .attr("name", "candidate");
    var wToptions = dropDown.selectAll("option")
      .data(uniqueCandidate)
      .enter()
      .append("option");
    wToptions.text(function(d) {
        return d;
      })
      .attr("value", function(d) {
        return d;
      });

    createMap(csvData);
})