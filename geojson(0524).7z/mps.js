var data;
d3.dsv(",", "ugmpelections1.csv", function(d) {
    return {
        source: d.source,
        target: d.target,
        value: +d.value
    }
}).then(function(_data) {
    data = _data;
    var uniqueCandidate = [...new Set(data.map(function(d) {
        return d.source;
    }))];

    //create dropdown lists
    var dropDown = d3.select("#mpsDropDown")
        .append("select")
        .on('change', searchNode)
        .attr("class", "Cselection")
        .attr("name", "source");
    var wToptions = dropDown.selectAll("option")
        .data(uniqueCandidate)
        .enter()
        .append("option");
    wToptions.text(function(d) {
            return d;
        })
        .attr("value", function(d) {
            return d;
        });

    // let e = document.querySelector(".Cselection");
    // var selectedOption = e.options[e.selectedIndex].value;
    // let links = data.filter(function(d) {
    //     return d.source == selectedOption;
    // })

    let links = data;
    drawGraph(links);

    function drawGraph(links) {
        var nodes = {};

        let elem = document.querySelector("svg");
        if (elem != null) {
            elem.remove();
        }

        // compute the distinct nodes from the links.
        links.forEach(function(link) {
            link.source = nodes[link.source] || (nodes[link.source] = { name: link.source });
            link.target = nodes[link.target] || (nodes[link.target] = { name: link.target });
            link.value = +link.value;
        });

        var color = d3.scaleOrdinal(d3.schemeCategory10);

        var width = 1500,
            height = 850;

        var force = d3.forceSimulation()
            .nodes(d3.values(nodes))
            .force("link", d3.forceLink(links).distance(150))
            .force('center', d3.forceCenter(width / 2, height / 2))
            .force("x", d3.forceX())
            .force("y", d3.forceY())
            .force("charge", d3.forceManyBody().strength(-350))
            .alphaTarget(1)
            .on("tick", tick);

        var svg = d3.select("body").append("svg")
            .attr("width", width)
            .attr("height", height);

        // add the links
        var path = svg.append("g")
            .selectAll("path")
            .data(links)
            .enter()
            .append("path")
            .attr("class", function(d) { return "link " + d.type; });


        // define the nodes
        var node = svg.selectAll(".node")
            .data(force.nodes())
            .enter().append("g")
            .attr("class", "node")
            .on("dblclick", doubleClick) // add doubleClick function
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        // add the nodes
        node.append("circle")
            .attr("r", 3);


        // add the curvy lines
        function tick() {
            path.attr("d", function(d) {
                var dx = d.target.x - d.source.x,
                    dy = d.target.y - d.source.y,
                    dr = Math.sqrt(dx * dx + dy * dy);
                return "M" +
                    d.source.x + "," +
                    d.source.y + "A" +
                    dr + "," + dr + " 0 0,1 " +
                    d.target.x + "," +
                    d.target.y;
            });

            node.attr("transform", function(d) {
                return "translate(" + d.x + "," + d.y + ")";
            });

        };

        // add the text
        node.append("text")
            .attr("x", 12)
            .attr("dy", ".35em")
            .text(function(d) { return d.name; });

        // Set Edge attributes
        var path = svg.append("g")
            .selectAll("path")
            .data(links)
            .enter()
            .append("path")
            .attr("class", function(d) { return "link " + d.type; })
            .style("stroke", function(d) {
                if (d.value == 1) { return ('green'); } else { return 'gray'; }
            })
            .attr('stroke-dasharray', function(d) {
                if (d.value === 1) {
                    return '5, 5';
                }
            })
            .style('stroke-width', function(d) {
                if (d.value === 0) {
                    return 5;
                }
            })

        // Node weight based on degree
        // Add degree
        d3.selectAll('.node')
            .each(function(d) {
                d.degree = 0;
            });

        // Calculate degree
        links.forEach(function(d) {
            d.source.degree += 1;
            d.target.degree += 1;
        });

        // Accessor functions to get min & max
        var minDegree = d3.min(
            d3.values(nodes),
            function(d) {
                return d.degree;
            })

        var maxDegree = d3.max(
            d3.values(nodes),
            function(d) {
                return d.degree;
            })

        // Create node scale based on degree
        var nodescale = d3.scaleSqrt()
            .domain([minDegree, maxDegree])
            .range([10, 40]); // Change this to your desired range


        // Add the node circles
        node.append("circle")
            .attr("r", function(d) {
                return nodescale(d.degree);
            })

        // Add color to node
        // Create node scale based on degree
        node.append("circle")
            .attr("r", function(d) {
                return nodescale(d.degree);
            })
            .style("fill", function(d) {
                var degree = nodescale(d.degree)
                if (degree <= 10)
                    return "#41b6c4"
                if (degree < 20)
                    return "#c51b8a"
                if (degree < 25)
                    return "#fecc5c"
                if (degree < 35)
                    return "#fd8d3c"
                if (degree < 40)
                    return "#f03b20"
                else
                    return "#bd0026"
            });

    }

    function searchNode() {
        let selectedOption = this.options[this.selectedIndex].value

        let links = new Array();
        data.forEach((d) => {
            if (d.source.name == selectedOption) {
                links.push({
                    source: d.source.name,
                    target: d.target.name,
                });
            }
        })

        drawGraph(links);

        return;

        //find the node
        var selectedVal = this.options[this.selectedIndex].value
        var node = svg.selectAll(".node");

        if (selectedVal == "none") {
            node.style("stroke", "white").style("stroke-width", "1");
        } else {
            var selected = node.filter(function(d, i) {
                return d.name != selectedVal;
            });

            selected.style("opacity", "0");
            //selected.style("display", "none");
            var link = svg.selectAll(".link")
            link.style("opacity", "0");

            d3.selectAll(".node, .link").transition()
                .duration(2000)
                .style("opacity", 1);


        }
    }

    ///// Start of this function
    function dragstarted(d) {
        if (!d3.event.active) force.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
    };

    function dragged(d) {
        d.fixed = true;
        d.fx = d3.event.x;
        d.fy = d3.event.y;
    };

    function dragended(d) {
        if (!d3.event.active) force.alphaTarget(0);
        if (d.fixed == true) {
            d.fx = d.x;
            d.fy = d.y;
            d3.select(this).select('circle').style('fill', '#f00').style('stroke-width', 100);
        } else {
            d.fx = null;
            d.fy = null;
        }
    };


    // double click function
    function doubleClick(d) {
        d.fx = null;
        d.fy = null;
        d3.select(this).select('circle').classed('fixed', d.fixed = false);
        force.restart();
    };


}).catch(function(error) {
    console.log(error);
});

/*
var node = gnodes.append("circle")
  .attr("class", "node")
  .attr("r", 5)
  .style("fill", function(d) {return d.colr; })
  .each(function() {
    var sel = d3.select(this);
    var state = false;
    sel.on('dblclick', function() {
      state = !state;
      if (state) {
        sel.style('fill', 'black');
      } else {
        sel.style('fill', function(d) { return d.colr; });
      }
    });
  });
*/